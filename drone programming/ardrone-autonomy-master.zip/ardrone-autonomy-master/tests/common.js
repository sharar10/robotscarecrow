var common = exports;
var path   = require('path');

common.root     = path.join(__dirname, '..');
common.lib      = path.join(common.root, 'lib');
