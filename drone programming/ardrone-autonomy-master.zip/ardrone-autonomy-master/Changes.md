# Changes

This file is a manually maintained list of changes for each release. Feel free
to send corrections if you spot any mistakes.

## v0.1.1 (2013-09-01)

* Fixed issue with cw/ccw yaw rotation
* Fixed issue with improper yaw reset on some moves
* Added ctrl-c logic to example for emegency landing

## v0.1.0 (2013-08-23)

* Initial release to npm

